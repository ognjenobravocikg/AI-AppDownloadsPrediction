#!/usr/local/bin/python3

import subprocess

try:
    import tkinter as tk
except ImportError:
    try:
        import subprocess
        subprocess.run(["pip", "install", "tkinter"])
        import tkinter as tk
    except Exception as e:
        print(f"Error installing tkinter: {e}")
        exit(1)


def result(App_name, Category, Price, Size, Minimum_android, Developer_id, Content_rating, Ad_supported, In_app_purchases):
    # Napraviti prozor gde se ispisuje predvidjanje
    print(App_name, Category, Price, Size, Minimum_android, Developer_id, Content_rating, Ad_supported, In_app_purchases)

def predict():
    App_name = entry_app_name.get()
    Category = entry_category.get()
    Price = entry_price.get()
    Size = entry_size.get()
    Minimum_android = entry_minimum_android.get()
    Developer_id = entry_developer_id.get()
    Content_rating = value_content_rating.get()
    Ad_supported = value_ad_supported.get()
    In_app_purchases = value_in_app_purchase.get()

    # KADA SE NAPRAVI FINALNA VERZIJA ML MODELA, PREIMENOVATI FAJL IZ "ime.ipynb" U "model.py" KAKO BI PROGRAM RADIO
    #subprocess.run(["python", "./model.py", App_name, Category, Price, Size, Minimum_android, Developer_id, Content_rating, Ad_supported, In_app_purchases])
    
    # pozivanje funkcije koja ce da prikaze predvidjanje
    result(App_name, Category, Price, Size, Minimum_android, Developer_id, Content_rating, Ad_supported, In_app_purchases) 


######################### Main window ######################### 
main = tk.Tk()
main.title("Guess number of downloads")

submit_button = tk.Button(main, text="Guess", command=predict)
submit_button.grid(row=8, column=0, columnspan=8, pady=20)


#################### Input textes #################### FRAME ENTRY TEXTES
frame_entry_textes = tk.Frame(main)
frame_entry_textes.grid(row=0, column=0, rowspan=6, columnspan=2, padx=16, pady=20)

##### App name #####
label_app_name = tk.Label(frame_entry_textes, text="App name")
label_app_name.grid(row=0, column=0, padx=10, pady=5)

entry_app_name = tk.Entry(frame_entry_textes)
entry_app_name.grid(row=0, column=1, padx=10, pady=5)

##### Category #####
label_category = tk.Label(frame_entry_textes, text="Category")
label_category.grid(row=1, column=0, padx=10, pady=2)

entry_category = tk.Entry(frame_entry_textes)
entry_category.grid(row=1, column=1, padx=10, pady=2)

##### Price #####
label_price = tk.Label(frame_entry_textes, text="Price")
label_price.grid(row=2, column=0, padx=10, pady=2)

entry_price = tk.Entry(frame_entry_textes)
entry_price.grid(row=2, column=1, padx=10, pady=2)

##### Size #####
label_size = tk.Label(frame_entry_textes, text="Size")
label_size.grid(row=3, column=0, padx=10, pady=2)

entry_size = tk.Entry(frame_entry_textes)
entry_size.grid(row=3, column=1, padx=10, pady=2)

##### Minimum android #####
label_minimum_android = tk.Label(frame_entry_textes, text="Minimum android")
label_minimum_android.grid(row=4, column=0, padx=10, pady=2)

entry_minimum_android = tk.Entry(frame_entry_textes)
entry_minimum_android.grid(row=4, column=1, padx=10, pady=2)

##### Developer id #####
label_developer_id = tk.Label(frame_entry_textes, text="Developer ID")
label_developer_id.grid(row=5, column=0, padx=10, pady=2)

entry_developer_id = tk.Entry(frame_entry_textes)
entry_developer_id.grid(row=5, column=1, padx=10, pady=2)

#################### Content rating #################### FRAME CONTENT RATING
frame_content_rating = tk.Frame(main)
frame_content_rating.grid(row=0, column=3, rowspan=7, padx=8, pady=20)

label_content_rating = tk.Label(frame_content_rating, text="Content rating")
label_content_rating.grid(row=0, column=0, padx=10, pady=2)

value_content_rating = tk.StringVar()
value_content_rating.set("Unrated")

content_ratings = ["Everyone", "Teen", "Mature 17+", "Everyone 10+", "Adults only 18+", "Unrated"]
for i, ratings in enumerate(content_ratings, start=1):
    radio_button = tk.Radiobutton(frame_content_rating, text=ratings, variable=value_content_rating, value=ratings)
    radio_button.grid(row=i, column=0, padx=10, pady=2)

#################### In app purchases #################### FRAME IN APP PURCHASE
frame_in_app_purchase = tk.Frame(main)
frame_in_app_purchase.grid(row=0, column=4, rowspan=3, padx=8, pady=20)

label_in_app_purchase = tk.Label(frame_in_app_purchase, text="In App Purchases?")
label_in_app_purchase.grid(row=0, column=0, padx=10, pady=2)

value_in_app_purchase = tk.StringVar()
value_in_app_purchase.set("no")

in_app_purchases = ["yes", "no"]
for i, in_app_purchase in enumerate(in_app_purchases, start=1):
    radio_button = tk.Radiobutton(frame_in_app_purchase, text=in_app_purchase, variable=value_in_app_purchase, value=in_app_purchase)
    radio_button.grid(row=i, column=0, padx=10, pady=2)

#################### Ad supported #################### FRAME AD SUPPORTED
frame_ad_supported = tk.Frame(main)
frame_ad_supported.grid(row=0, column=5, rowspan=3, padx=8, pady=20)

value_ad_supported = tk.StringVar()
value_ad_supported.set("no")

label_ad_supported = tk.Label(frame_ad_supported, text="Ad supported?")
label_ad_supported.grid(row=0, column=0, padx=10, pady=2)

ad_supported = ["yes", "no"]
for i, yn in enumerate(ad_supported, start=1):
    radio_button = tk.Radiobutton(frame_ad_supported, text=yn, variable=value_ad_supported, value=yn)
    radio_button.grid(row=i, column=0, padx=10, pady=2)

######################### Pokretanje prozora ######################### 

main.mainloop()